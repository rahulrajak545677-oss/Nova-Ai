// One-step setup: node setup.js  (run `npm install` first)
// Adds the Android project, installs the native floating-bubble service, patches permissions, syncs the web app.
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const run = c => { console.log('> ' + c); execSync(c, { stdio: 'inherit' }); };

if (!fs.existsSync('android')) run('npx cap add android');

// 1) Native floating bubble: copy Java sources into the app package
const cfg = JSON.parse(fs.readFileSync('capacitor.config.json', 'utf8'));
const pkg = cfg.appId;
const jdir = path.join('android', 'app', 'src', 'main', 'java', ...pkg.split('.'));
fs.mkdirSync(jdir, { recursive: true });
for (const f of ['MainActivity.java', 'NovaOverlayPlugin.java', 'OverlayService.java']) {
  const src = fs.readFileSync(path.join('native', f), 'utf8').replace(/__PKG__/g, pkg);
  fs.writeFileSync(path.join(jdir, f), src);
  console.log('Installed ' + f);
}

// 2) Manifest: permissions + overlay service
const mf = 'android/app/src/main/AndroidManifest.xml';
let m = fs.readFileSync(mf, 'utf8');
const perms = ['RECORD_AUDIO', 'CAMERA', 'MODIFY_AUDIO_SETTINGS', 'SYSTEM_ALERT_WINDOW',
  'FOREGROUND_SERVICE', 'FOREGROUND_SERVICE_SPECIAL_USE', 'POST_NOTIFICATIONS'];
let add = '';
for (const p of perms) if (!m.includes('android.permission.' + p + '"')) add += `    <uses-permission android:name="android.permission.${p}" />\n`;
if (!m.includes('android.speech.RecognitionService'))
  add += '    <queries><intent><action android:name="android.speech.RecognitionService" /></intent></queries>\n';
if (add) m = m.replace('</manifest>', add + '</manifest>');
if (!m.includes('.OverlayService')) {
  const svc = `        <service android:name=".OverlayService" android:exported="false" android:foregroundServiceType="specialUse">
            <property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="floating assistant bubble" />
        </service>
    `;
  m = m.replace('</application>', svc + '</application>');
}
fs.writeFileSync(mf, m);
console.log('Manifest patched.');

try { run('npx capacitor-assets generate --android'); } catch (e) { console.log('Icon generation skipped.'); }
run('npx cap sync android');
console.log('\nDone. Next: npm run open  (opens Android Studio), then Build > Build APK(s).');
