# NOVA AI 1.1: complete Android project

NOVA AI as a real Android app (Capacitor). The app itself is `www/index.html`.
I could not build the APK for you (no Android SDK where I work), so use one of the two routes below.
Versions and the cloud build were written from documentation and are untested.

## Route A: build in the cloud from your phone or PC (no Android Studio)
1. Create a free GitHub account and a new empty repository.
2. Upload everything from this folder (keep the `.github` folder).
3. Open the repo > **Actions** > **Build NOVA APK** > **Run workflow**.
4. When it finishes, open the run and download **nova-ai-debug-apk** (a zip containing `app-debug.apk`).
5. Install `app-debug.apk` on your phone (allow "install unknown apps").

## Route B: build on your computer
Needs Node.js (LTS) and Android Studio.
1. `npm install`
2. `node setup.js`  (adds Android, microphone/camera permissions, icon, syncs)
3. `npm run open`   (opens Android Studio) > Build > Build APK(s)
   or `npm run apk` > `android/app/build/outputs/apk/debug/app-debug.apk`
Run `npx cap doctor` if versions complain.

## Connect the AI (keys inside the app)
Open the app > Settings > AI provider.
- Gemini key (free): https://aistudio.google.com/apikey, plus a model name. Tap **Test**.
- TinyFish key (optional): https://agent.tinyfish.ai/api-keys, for web search and link reading.
Keys stay on your phone and are sent only to Google and TinyFish. Never write your keys into the code
or share an APK that contains them. You can restrict or delete a key in Google AI Studio.

## Languages
Settings > App language: English, Hindi, Spanish, French, Arabic (right-to-left), Portuguese.
This changes menus and buttons. Replies already follow the language you write in.
"Translate screen to" sets the language used when translating screenshots.

## Features
Chat with streaming replies, app/website previews, floating bubble with quick chat, hands-free voice chat,
read-aloud, memory, image and screenshot understanding, camera, reply length, projects, library, export.

## After editing www/index.html
Run `npm run sync`, then build again (Route A: just upload the changed file).

## New in 1.1
- **Floating bubble over other apps** (native Android service). First time: Settings > Floating bubble > Allow in Android settings, switch on "Display over other apps" for NOVA, come back. Tap the bubble for a fresh quick chat; close it and the chat is gone. Drag to move; it snaps to the edge. "Hide bubble" is in its notification.
- **Image creation**: ask "create an image of..." or use + > Create an image. Gemini image model first (needs billing on your key), free engine as fallback. Save/share from the image.
- **Premium settings**: every option has an icon, a name and a line saying what it does.
- Fixed: Retry after an error now resends your own message.

## Limits
- It cannot read other apps' screens. Attach a screenshot with + > Photo or screenshot.
- The bubble quick chat is text-only; apps, websites and images open the full app.
- Free image engine is rate limited (about one image per 15 seconds) and may add a watermark.
- Optional: `worker/worker.js` is a server you can host yourself (Settings > Advanced). Set its
  `ALLOWED_ORIGIN` to `https://localhost`.
