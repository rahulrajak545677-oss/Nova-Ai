package __PKG__;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Bridge between the NOVA web app and the native floating bubble service. */
@CapacitorPlugin(name = "NovaOverlay")
public class NovaOverlayPlugin extends Plugin {

    private SharedPreferences sp() {
        return getContext().getSharedPreferences("nova_overlay", Context.MODE_PRIVATE);
    }

    @PluginMethod
    public void status(PluginCall call) {
        JSObject o = new JSObject();
        o.put("granted", Settings.canDrawOverlays(getContext()));
        o.put("running", OverlayService.running);
        o.put("stoppedByUser", sp().getBoolean("stopped_by_user", false));
        call.resolve(o);
    }

    @PluginMethod
    public void requestPermission(PluginCall call) {
        sp().edit().putBoolean("stopped_by_user", false).apply();
        if (!Settings.canDrawOverlays(getContext())) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getContext().getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        }
        call.resolve();
    }

    @PluginMethod
    public void start(PluginCall call) {
        if (!Settings.canDrawOverlays(getContext())) {
            call.reject("permission");
            return;
        }
        sp().edit().putBoolean("stopped_by_user", false).apply();
        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(getContext(), Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
                && getActivity() != null) {
            ActivityCompat.requestPermissions(getActivity(),
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, 4242);
        }
        try {
            Intent s = new Intent(getContext(), OverlayService.class);
            ContextCompat.startForegroundService(getContext(), s);
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not start: " + e.getMessage());
        }
    }

    @PluginMethod
    public void stop(PluginCall call) {
        getContext().stopService(new Intent(getContext(), OverlayService.class));
        call.resolve();
    }

    @PluginMethod
    public void configure(PluginCall call) {
        JSObject data = call.getData();
        sp().edit().putString("cfg", data.toString()).apply();
        call.resolve();
    }
}
