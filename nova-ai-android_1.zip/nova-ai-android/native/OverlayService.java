package __PKG__;

import android.animation.ValueAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * Floating NOVA bubble that stays on top of every app.
 * Tap the bubble: a fresh quick-chat panel opens. Close it: the chat is gone.
 */
public class OverlayService extends Service {

    static final String CH = "nova_overlay";
    static final String ACTION_STOP = "__PKG__.STOP_OVERLAY";
    static volatile boolean running = false;

    private WindowManager wm;
    private BubbleView bubble;
    private WindowManager.LayoutParams bp;
    private PanelLayout panel;
    private WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private float d = 1f;
    private int W, H;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            prefs().edit().putBoolean("stopped_by_user", true).apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            startFg();
        } catch (Exception ignored) {
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (bubble == null) addBubble();
        running = true;
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        closePanel();
        if (bubble != null && wm != null) {
            try {
                wm.removeView(bubble);
            } catch (Exception ignored) {
            }
            bubble = null;
        }
        super.onDestroy();
    }

    private SharedPreferences prefs() {
        return getSharedPreferences("nova_overlay", Context.MODE_PRIVATE);
    }

    private JSONObject cfg() {
        try {
            return new JSONObject(prefs().getString("cfg", "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    /* ---------- foreground notification ---------- */
    private void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH, "NOVA floating bubble",
                    NotificationManager.IMPORTANCE_LOW);
            c.setShowBadge(false);
            nm.createNotificationChannel(c);
        }
        int imm = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0;
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pOpen = PendingIntent.getActivity(this, 0, open, imm);
        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent pStop = PendingIntent.getService(this, 1, stop, imm);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CH)
                : new Notification.Builder(this);
        b.setContentTitle("NOVA bubble is on")
                .setContentText("Tap the bubble anywhere to chat. Tap here to open NOVA.")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setContentIntent(pOpen)
                .setOngoing(true)
                .addAction(0, "Hide bubble", pStop);
        Notification n = b.build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(7, n);
        }
    }

    /* ---------- bubble ---------- */
    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    private void measure() {
        W = getResources().getDisplayMetrics().widthPixels;
        H = getResources().getDisplayMetrics().heightPixels;
    }

    private int size() {
        return (int) (56 * d);
    }

    private void addBubble() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        d = getResources().getDisplayMetrics().density;
        measure();
        bubble = new BubbleView(this);
        bp = new WindowManager.LayoutParams(size(), size(), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        bp.gravity = Gravity.TOP | Gravity.START;
        SharedPreferences sp = prefs();
        bp.x = sp.getInt("bx", W - size() - (int) (6 * d));
        bp.y = sp.getInt("by", (int) (H * 0.45f));
        clamp();
        bubble.setOnTouchListener(new DragListener());
        wm.addView(bubble, bp);
    }

    private void clamp() {
        measure();
        bp.x = Math.max(0, Math.min(W - size(), bp.x));
        bp.y = Math.max((int) (30 * d), Math.min(H - size() - (int) (40 * d), bp.y));
    }

    private void snap() {
        measure();
        final int from = bp.x;
        final int to = (from + size() / 2 < W / 2) ? (int) (6 * d) : W - size() - (int) (6 * d);
        ValueAnimator a = ValueAnimator.ofInt(from, to);
        a.setDuration(220);
        a.addUpdateListener(v -> {
            if (bubble == null) return;
            bp.x = (Integer) v.getAnimatedValue();
            try {
                wm.updateViewLayout(bubble, bp);
            } catch (Exception ignored) {
            }
        });
        a.start();
        prefs().edit().putInt("bx", to).putInt("by", bp.y).apply();
    }

    private class DragListener implements View.OnTouchListener {
        float downX, downY;
        int startX, startY;
        boolean moved;

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startX = bp.x;
                    startY = bp.y;
                    downX = e.getRawX();
                    downY = e.getRawY();
                    moved = false;
                    bubble.setPressedState(true);
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float mx = e.getRawX() - downX, my = e.getRawY() - downY;
                    if (!moved && Math.abs(mx) + Math.abs(my) > 12 * d) {
                        moved = true;
                        if (panel != null) closePanel();
                    }
                    if (moved) {
                        bp.x = (int) (startX + mx);
                        bp.y = (int) (startY + my);
                        clamp();
                        try {
                            wm.updateViewLayout(bubble, bp);
                        } catch (Exception ignored) {
                        }
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    bubble.setPressedState(false);
                    if (moved) snap();
                    else if (e.getAction() == MotionEvent.ACTION_UP) togglePanel();
                    return true;
            }
            return false;
        }
    }

    /** Round glowing NOVA bubble with the sparkle logo. */
    private static class BubbleView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint star = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path sparkle = new Path();
        private boolean pressed;

        BubbleView(Context c) {
            super(c);
            ring.setStyle(Paint.Style.STROKE);
            ring.setColor(0xAA8B78FF);
            star.setColor(Color.WHITE);
            dot.setColor(0xFF4ADE80);
            sparkle.moveTo(12, 1);
            sparkle.quadTo(13.5f, 10.5f, 23, 12);
            sparkle.quadTo(13.5f, 13.5f, 12, 23);
            sparkle.quadTo(10.5f, 13.5f, 1, 12);
            sparkle.quadTo(10.5f, 10.5f, 12, 1);
            sparkle.close();
        }

        void setPressedState(boolean p) {
            pressed = p;
            setScaleX(p ? 0.92f : 1f);
            setScaleY(p ? 0.92f : 1f);
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), r = w / 2f, dn = getResources().getDisplayMetrics().density;
            fill.setShader(new RadialGradient(w * 0.32f, w * 0.28f, w * 0.85f,
                    new int[]{0xFF5B4BD8, 0xFF1A1A22, 0xFF0F0F14}, new float[]{0f, 0.65f, 1f},
                    Shader.TileMode.CLAMP));
            c.drawCircle(r, r, r - 3 * dn, fill);
            ring.setStrokeWidth(1.6f * dn);
            c.drawCircle(r, r, r - 3 * dn, ring);
            c.save();
            float s = (w * 0.46f) / 24f;
            c.translate(r - 12 * s, r - 12 * s);
            c.scale(s, s);
            c.drawPath(sparkle, star);
            c.restore();
            c.drawCircle(w - 11 * dn, 11 * dn, 4.2f * dn, dot);
        }
    }

    /* ---------- quick chat panel ---------- */
    private void togglePanel() {
        if (panel != null) closePanel();
        else openPanel();
    }

    private class PanelLayout extends FrameLayout {
        PanelLayout(Context c) {
            super(c);
        }

        @Override
        public boolean dispatchKeyEvent(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.KEYCODE_BACK) {
                if (e.getAction() == KeyEvent.ACTION_UP) closePanel();
                return true;
            }
            return super.dispatchKeyEvent(e);
        }
    }

    private void openPanel() {
        measure();
        int pw = Math.min((int) (360 * d), W - (int) (20 * d));
        int ph = (int) Math.min(H * 0.52f, 480 * d);

        panel = new PanelLayout(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF0F0F12);
        bg.setCornerRadius(24 * d);
        bg.setStroke((int) d, 0x668B78FF);
        panel.setBackground(bg);
        panel.setClipToOutline(true);

        Context themed = new ContextThemeWrapper(getApplicationContext(),
                android.R.style.Theme_DeviceDefault_NoActionBar);
        web = new WebView(themed);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.setBackgroundColor(Color.TRANSPARENT);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/public/quick.html");
        panel.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WindowManager.LayoutParams pp = new WindowManager.LayoutParams(pw, ph, overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        pp.gravity = Gravity.TOP | Gravity.START;
        pp.x = (W - pw) / 2;
        pp.y = (int) (H * 0.07f);
        pp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
        try {
            wm.addView(panel, pp);
            // keep the bubble on top so it can always close the panel
            wm.removeView(bubble);
            wm.addView(bubble, bp);
        } catch (Exception e) {
            closePanel();
        }
    }

    private void closePanel() {
        if (panel == null) return;
        try {
            wm.removeView(panel);
        } catch (Exception ignored) {
        }
        panel.removeAllViews();
        if (web != null) {
            web.stopLoading();
            web.destroy();
            web = null;
        }
        panel = null;
    }

    /* ---------- JS bridge used by quick.html ---------- */
    public class Bridge {
        @JavascriptInterface
        public String config() {
            return cfg().toString();
        }

        @JavascriptInterface
        public void close() {
            ui.post(OverlayService.this::closePanel);
        }

        @JavascriptInterface
        public void openApp() {
            ui.post(() -> {
                closePanel();
                Intent i = new Intent(OverlayService.this, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(i);
            });
        }

        @JavascriptInterface
        public void ask(final String json) {
            new Thread(() -> doAsk(json)).start();
        }
    }

    private static String readAll(InputStream is) throws Exception {
        if (is == null) return "";
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
        return bo.toString("UTF-8");
    }

    private void doAsk(String json) {
        String id = "";
        String out = "";
        boolean ok = true;
        try {
            JSONObject req = new JSONObject(json);
            id = req.optString("id");
            JSONObject c = cfg();
            String key = c.optString("gk", "");
            if (key.isEmpty()) throw new Exception("Add your Gemini key in NOVA > Settings first.");
            String model = c.optString("gm", "");
            if (model.isEmpty()) model = "gemini-3.5-flash-lite";

            JSONArray msgs = req.getJSONArray("messages");
            JSONArray contents = new JSONArray();
            for (int i = 0; i < msgs.length(); i++) {
                JSONObject m = msgs.getJSONObject(i);
                JSONObject part = new JSONObject().put("text", m.getString("content"));
                contents.put(new JSONObject()
                        .put("role", "assistant".equals(m.getString("role")) ? "model" : "user")
                        .put("parts", new JSONArray().put(part)));
            }
            JSONObject body = new JSONObject();
            body.put("systemInstruction", new JSONObject().put("parts",
                    new JSONArray().put(new JSONObject().put("text", c.optString("system", "")))));
            body.put("contents", contents);
            body.put("generationConfig", new JSONObject().put("temperature", c.optDouble("temp", 0.8)));

            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/"
                    + URLEncoder.encode(model, "UTF-8") + ":generateContent");
            HttpURLConnection h = (HttpURLConnection) url.openConnection();
            h.setRequestMethod("POST");
            h.setRequestProperty("Content-Type", "application/json");
            h.setRequestProperty("x-goog-api-key", key);
            h.setConnectTimeout(15000);
            h.setReadTimeout(60000);
            h.setDoOutput(true);
            OutputStream os = h.getOutputStream();
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            os.close();

            int code = h.getResponseCode();
            String resp = readAll(code >= 200 && code < 300 ? h.getInputStream() : h.getErrorStream());
            if (code < 200 || code >= 300) {
                String msg = "";
                try {
                    msg = new JSONObject(resp).getJSONObject("error").getString("message");
                } catch (Exception ignored) {
                }
                throw new Exception(code == 429
                        ? "Free quota reached. Try again in a minute."
                        : "Gemini error " + code + (msg.isEmpty() ? "" : ": " + msg));
            }
            JSONObject r = new JSONObject(resp);
            JSONArray cands = r.optJSONArray("candidates");
            if (cands == null || cands.length() == 0) throw new Exception("No answer. Try rephrasing.");
            JSONArray parts = cands.getJSONObject(0).getJSONObject("content").getJSONArray("parts");
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < parts.length(); i++) sb.append(parts.getJSONObject(i).optString("text", ""));
            out = sb.toString();
        } catch (Exception e) {
            ok = false;
            out = e.getMessage() == null ? "Something went wrong." : e.getMessage();
        }
        final String fid = id, fout = out;
        final boolean fok = ok;
        ui.post(() -> {
            if (web != null) {
                web.evaluateJavascript("window.onAnswer(" + JSONObject.quote(fid) + "," + fok + ","
                        + JSONObject.quote(fout) + ")", null);
            }
        });
    }
}
