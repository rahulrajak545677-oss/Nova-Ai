// One-step setup: node setup.js  (run `npm install` first)
const { execSync } = require('child_process');
const fs = require('fs');
const run = c => { console.log('> ' + c); execSync(c, { stdio: 'inherit' }); };

if (!fs.existsSync('android')) run('npx cap add android');

// Permissions: microphone (voice), camera (photos), speech service lookup
const f = 'android/app/src/main/AndroidManifest.xml';
let m = fs.readFileSync(f, 'utf8');
const perms = ['RECORD_AUDIO', 'CAMERA', 'MODIFY_AUDIO_SETTINGS'];
let add = '';
for (const p of perms) if (!m.includes('android.permission.' + p)) add += `    <uses-permission android:name="android.permission.${p}" />\n`;
if (!m.includes('android.speech.RecognitionService'))
  add += '    <queries><intent><action android:name="android.speech.RecognitionService" /></intent></queries>\n';
if (add) { m = m.replace('</manifest>', add + '</manifest>'); fs.writeFileSync(f, m); console.log('Manifest patched.'); }

try { run('npx capacitor-assets generate --android'); } catch (e) { console.log('Icon generation skipped.'); }
run('npx cap sync android');
console.log('\nDone. Next: npm run open  (opens Android Studio), then Build > Build APK(s).');
